# TahsilatPro APK oluşturma

1. ZIP'i açın ve içindeki `TahsilatPro` klasörünü GitHub'da yeni bir repository'ye yükleyin.
2. Repository'de Actions sekmesine girin.
3. `Build TahsilatPro APK` iş akışını seçin.
4. `Run workflow` ile çalıştırın.
5. İşlem bitince workflow sayfasındaki `Artifacts` bölümünden `TahsilatPro-debug-apk` dosyasını indirin.
6. ZIP'i açın; içindeki APK'ya Android telefonda dokunup kurun.

Not: Bu workflow debug APK üretir. Gerçek ortak kullanıcı/veri sistemi için Firebase yapılandırması ayrıca yapılmalıdır; `google-services.json` projeye dahil değildir.
