Bu klasörde üretim sürümünde Room/Firebase veri katmanı tutulacaktır.

Önerilen koleksiyon:
payments/{paymentId}
  employeeId
  employeeName
  customerName
  amount
  currency
  note
  createdAt
  updatedAt
  status
  createdBy
  editedBy

Önerilen roller:
- ADMIN: tüm kayıtları görür/düzenler/siler, çalışan yönetir, rapor alır.
- EMPLOYEE: tahsilat ekler ve kendi kayıtlarını görür.
