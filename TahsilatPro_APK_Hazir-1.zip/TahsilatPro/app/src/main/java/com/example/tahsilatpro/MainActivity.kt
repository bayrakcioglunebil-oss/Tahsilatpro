package com.example.tahsilatpro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.NumberFormat
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

data class Payment(
    val id: String,
    val employee: String,
    val customer: String,
    val amount: Double,
    val note: String,
    val timestamp: LocalDateTime = LocalDateTime.now(),
    val status: String = "Tamamlandı"
)

private val samplePayments = listOf(
    Payment("1","Mahmoud","Musteri A",650.0,"Nakit"),
    Payment("2","Ibo","Musteri B",420.0,"Kart"),
    Payment("3","Mahmoud","Musteri C",850.0,"Havale")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TahsilatProApp() }
    }
}

@Composable
fun TahsilatProApp() {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = androidx.compose.ui.graphics.Color(0xFF155EEF),
            background = androidx.compose.ui.graphics.Color(0xFFF7F8FA),
            surface = androidx.compose.ui.graphics.Color.White
        )
    ) {
        var loggedIn by remember { mutableStateOf(false) }
        if (!loggedIn) LoginScreen { loggedIn = true } else DashboardScreen()
    }
}

@Composable
fun LoginScreen(onLogin: () -> Unit) {
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier.fillMaxSize().padding(28.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text("Tahsilat Pro", fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Text("Hızlı, güvenli ve profesyonel tahsilat yönetimi", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(28.dp))
            OutlinedTextField(user, { user = it }, Modifier.fillMaxWidth(), label={Text("Kullanıcı / E-posta")}, singleLine=true)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(pass, { pass = it }, Modifier.fillMaxWidth(), label={Text("Şifre")}, singleLine=true)
            Spacer(Modifier.height(20.dp))
            Button(onClick=onLogin, Modifier.fillMaxWidth().height(52.dp), shape=RoundedCornerShape(14.dp)) {
                Text("Giriş Yap")
            }
            Spacer(Modifier.height(12.dp))
            Text("Demo: yönetici / çalışan hesapları Firebase bağlandığında aktif olacaktır.",
                fontSize=12.sp, color=MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen() {
    var payments by remember { mutableStateOf(samplePayments) }
    var showAdd by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var selectedEmployee by remember { mutableStateOf("Tümü") }
    val filtered = payments.filter {
        (selectedEmployee=="Tümü" || it.employee==selectedEmployee) &&
        (query.isBlank() || it.customer.contains(query, true) || it.employee.contains(query, true))
    }
    val total = filtered.sumOf { it.amount }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Column {
                    Text("Yönetim Paneli", fontWeight=FontWeight.Bold)
                    Text("Tahsilat Pro", fontSize=12.sp)
                }},
                actions = { IconButton({}) { Icon(Icons.Default.Notifications, "Bildirimler") } }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick={showAdd=true},
                icon={Icon(Icons.Default.Add,"Ekle")},
                text={Text("Tahsilat Ekle")}
            )
        }
    ) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad).padding(horizontal=16.dp),
            verticalArrangement=Arrangement.spacedBy(12.dp),
            contentPadding=PaddingValues(vertical=16.dp, bottom=100.dp)
        ) {
            item {
                Card(shape=RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(20.dp)) {
                        Text("Genel Toplam", color=MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(euro(total), fontSize=30.sp, fontWeight=FontWeight.Bold)
                        Spacer(Modifier.height(14.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
                            Stat("Mahmoud", euro(payments.filter{it.employee=="Mahmoud"}.sumOf{it.amount}))
                            Stat("İbo", euro(payments.filter{it.employee=="Ibo"}.sumOf{it.amount}))
                        }
                    }
                }
            }
            item {
                OutlinedTextField(
                    query,{query=it},Modifier.fillMaxWidth(),
                    placeholder={Text("Müşteri veya çalışan ara…")},
                    leadingIcon={Icon(Icons.Default.Search,"Ara")},
                    singleLine=true, shape=RoundedCornerShape(14.dp)
                )
            }
            item {
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    FilterChip(selectedEmployee=="Tümü",{selectedEmployee="Tümü"},label={Text("Tümü")})
                    FilterChip(selectedEmployee=="Mahmoud",{selectedEmployee="Mahmoud"},label={Text("Mahmoud")})
                    FilterChip(selectedEmployee=="Ibo",{selectedEmployee="Ibo"},label={Text("İbo")})
                }
            }
            item { Text("Son Tahsilatlar", fontWeight=FontWeight.Bold, fontSize=20.sp) }
            items(filtered, key={it.id}) { PaymentCard(it) }
        }
    }
    if (showAdd) {
        AddPaymentDialog(
            onDismiss={showAdd=false},
            onSave={p -> payments = listOf(p)+payments; showAdd=false}
        )
    }
}

@Composable
fun Stat(name:String,value:String) {
    Column {
        Text(name, fontSize=12.sp, color=MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontWeight=FontWeight.SemiBold)
    }
}

@Composable
fun PaymentCard(p: Payment) {
    Card(shape=RoundedCornerShape(16.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment=Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(p.customer, fontWeight=FontWeight.SemiBold)
                Text("${p.employee} • ${p.timestamp.format(DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm"))}",
                    fontSize=12.sp, color=MaterialTheme.colorScheme.onSurfaceVariant)
                if (p.note.isNotBlank()) Text(p.note, fontSize=12.sp)
            }
            Text(euro(p.amount), fontWeight=FontWeight.Bold, fontSize=17.sp)
        }
    }
}

@Composable
fun AddPaymentDialog(onDismiss:()->Unit,onSave:(Payment)->Unit) {
    var employee by remember { mutableStateOf("Mahmoud") }
    var customer by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest=onDismiss,
        title={Text("Yeni Tahsilat")},
        text={
            Column(verticalArrangement=Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    FilterChip(employee=="Mahmoud",{employee="Mahmoud"},label={Text("Mahmoud")})
                    FilterChip(employee=="Ibo",{employee="Ibo"},label={Text("İbo")})
                }
                OutlinedTextField(customer,{customer=it},label={Text("Müşteri adı")},singleLine=true)
                OutlinedTextField(amount,{amount=it},label={Text("Tutar (€)")},singleLine=true)
                OutlinedTextField(note,{note=it},label={Text("Not / ödeme yöntemi")},singleLine=true)
            }
        },
        confirmButton={
            Button(
                enabled=customer.isNotBlank() && amount.toDoubleOrNull()!=null,
                onClick={onSave(Payment(
                    System.currentTimeMillis().toString(),employee,customer,amount.toDouble(),note
                ))}
            ){Text("Kaydet")}
        },
        dismissButton={TextButton(onClick=onDismiss){Text("İptal")}}
    )
}

fun euro(v:Double):String = NumberFormat.getCurrencyInstance(Locale.GERMANY).format(v)
