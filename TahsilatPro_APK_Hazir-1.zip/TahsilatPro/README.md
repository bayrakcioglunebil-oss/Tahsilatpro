# Tahsilat Pro — Android

Bu proje, hızlı bir tahsilat takip uygulaması için profesyonel başlangıç iskeletidir.

## Özellikler
- Yönetici / çalışan rol mimarisi için hazır yapı
- Mahmoud ve İbo çalışan profilleri
- Tahsilat ekleme
- Müşteri adı, tutar, not
- Otomatik tarih-saat
- Çalışana göre filtre
- Arama
- Günlük/toplam dashboard
- Basit, hızlı Material 3 arayüz
- Firebase Authentication + Firestore entegrasyonuna hazır Gradle bağımlılıkları
- Offline-first üretim sürümü için Room altyapısı eklenebilir

## Firebase kurulumu
1. Firebase Console'da Android uygulaması oluştur.
2. Package name: com.example.tahsilatpro
3. google-services.json dosyasını app/ içine koy.
4. Authentication > Email/Password'u etkinleştir.
5. Firestore Database oluştur.
6. Firestore Security Rules ile ADMIN/EMPLOYEE rollerini sınırla.

## Üretim sürümünde eklenmesi önerilen profesyonel özellikler
- Gerçek Firebase repository ve güvenlik kuralları
- Room offline cache + otomatik senkronizasyon
- Audit log: kim, neyi, ne zaman değiştirdi
- Excel/CSV/PDF raporu
- Tarih aralığı ve ödeme yöntemi filtreleri
- Günlük/haftalık/aylık grafikler
- İade/iptal işlemleri
- Otomatik yedekleme
- Push bildirimleri
- PIN/biometric hızlı giriş
- Çoklu para birimi
- Müşteri cari bakiye takibi
- Kasa/banka ödeme yöntemi ayrımı
- Sayfalama ile büyük veri performansı
- Hata loglama ve crash monitoring

Not: google-services.json bu pakete dahil değildir; Firebase projenize ait özel dosyadır.
